<?php
//Discuz! cache file, DO NOT modify me!
//Identify: b02b0e3f68e6eee5caf51261e5b5ad5b

lang('admincp_searchindex');
$searchindex = & $_G['lang']['admincp_searchindex'];?>