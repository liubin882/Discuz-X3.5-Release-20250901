<?php


define('UC_CONNECT', 'mysql');
define('UC_STANDALONE', 1);

define('UC_DBHOST', '127.0.0.1');
define('UC_DBUSER', 'root');
define('UC_DBPW', 'DRsXT5ZJ6Oi55LPQ');
define('UC_DBNAME', 'ultrax');
define('UC_DBCHARSET', 'utf8mb4');
define('UC_DBTABLEPRE', '`ultrax`.pre_ucenter_');
define('UC_DBCONNECT', 0);

define('UC_AVTURL', '');
define('UC_AVTPATH', '');

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'deQf0aocf4eaS8Db17b12bM5lad1y7ibRdSdIdidLbSdd3Me16v4g31eIevfc2I7');
define('UC_API', 'http://127.0.0.1/dz/uc_server');
define('UC_APPID', '1');
define('UC_IP', '');
define('UC_PPP', 20);
?>