<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 056d66e2249a24965f4cb3acb69c644a

$mobilecheck = '{"discuzversion":"X3.5","charset":"utf-8","version":"4","pluginversion":"1.4.8","oemversion":"0","regname":"register","qqconnect":"0","sitename":"Discuz! Board","mysiteid":"","ucenterurl":".","setting":{"closeforumorderby":"0"},"extends":{"used":null,"lastupdate":null}}';
?>