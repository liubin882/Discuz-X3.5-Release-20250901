<?php
//Discuz! cache file, DO NOT modify me!
//Identify: da5e96a26cafb0c46628c6cf484f73a7

$pluginsetting = array (
);
?>